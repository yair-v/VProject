import { useEffect, useMemo, useState } from 'react';
import { api } from '../api';
import AppBrand from '../components/AppBrand';

const SETTINGS_TILES_ORDER_KEY = 'vproject.settings.tiles.order.v1';
const DEFAULT_SETTINGS_TILES_ORDER = ['statuses', 'customers', 'installers'];

function normalizeSettingsTilesOrder(savedOrder) {
  const saved = Array.isArray(savedOrder) ? savedOrder : [];
  return [
    ...saved.filter((key) => DEFAULT_SETTINGS_TILES_ORDER.includes(key)),
    ...DEFAULT_SETTINGS_TILES_ORDER.filter((key) => !saved.includes(key))
  ];
}

function DraggableSettingsTile({ tileKey, title, children, onDragStart, onDragOver, onDrop, isDragging }) {
  return (
    <section
      className={`card glass-card settings-panel settings-draggable-tile ${isDragging ? 'dragging' : ''}`}
      draggable
      onDragStart={(e) => onDragStart(e, tileKey)}
      onDragOver={(e) => onDragOver(e, tileKey)}
      onDrop={(e) => onDrop(e, tileKey)}
      onDragEnd={(e) => onDragStart(e, null)}
    >
      <div className="settings-drag-handle" title="גרור כדי לשנות סדר">↕ גרירה</div>
      {children}
    </section>
  );
}


function DisplaySettingsTab({ displaySettings, setDisplaySettings }) {
  return (
    <section className="card glass-card settings-panel">
      <div className="card-title-row">
        <div>
          <div className="section-chip">Display</div>
          <h3>תצוגה</h3>
        </div>
      </div>

      <div className="settings-grid">
        <label className="field">
          <span>ערכת נושא</span>
          <div className="segmented-status">
            <button
              type="button"
              className={displaySettings.theme === 'dark' ? 'active' : ''}
              onClick={() => setDisplaySettings((prev) => ({ ...prev, theme: 'dark' }))}
            >
              כהה
            </button>

            <button
              type="button"
              className={displaySettings.theme === 'light' ? 'active' : ''}
              onClick={() => setDisplaySettings((prev) => ({ ...prev, theme: 'light' }))}
            >
              בהיר
            </button>
          </div>
        </label>

        <label className="field">
          <span>זום: {displaySettings.zoom}%</span>
          <input
            type="range"
            min="75"
            max="125"
            step="5"
            value={displaySettings.zoom}
            onChange={(e) =>
              setDisplaySettings((prev) => ({
                ...prev,
                zoom: Number(e.target.value)
              }))
            }
          />
        </label>
      </div>
    </section>
  );
}

function UsersTab({ user }) {
  const [users, setUsers] = useState([]);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('manager');
  const [error, setError] = useState('');
  const [twofaModal, setTwofaModal] = useState(null);
  const [twofaCode, setTwofaCode] = useState('');
  const [loading2FA, setLoading2FA] = useState(false);

  async function loadUsers() {
    try {
      setUsers(await api.getUsers());
      setError('');
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    if (user.role === 'admin') loadUsers();
  }, [user.role]);

  async function createUser() {
    try {
      await api.createUser({ username, password, role });
      setUsername('');
      setPassword('');
      setRole('manager');
      await loadUsers();
    } catch (err) {
      setError(err.message);
    }
  }

  async function changeRole(item, newRole) {
    try {
      await api.updateUserRole(item.id, newRole);
      await loadUsers();
    } catch (err) {
      setError(err.message);
    }
  }

  async function changePassword(item) {
    const newPassword = window.prompt(`סיסמה חדשה עבור ${item.username}`);
    if (!newPassword?.trim()) return;

    try {
      await api.updateUserPassword(item.id, newPassword.trim());
      setError('');
      window.alert('הסיסמה עודכנה');
    } catch (err) {
      setError(err.message);
    }
  }

  async function removeUser(item) {
    if (!window.confirm(`למחוק את המשתמש ${item.username}?`)) return;

    try {
      await api.deleteUser(item.id);
      await loadUsers();
    } catch (err) {
      setError(err.message);
    }
  }

  async function setup2FA(item) {
    setLoading2FA(true);
    setError('');
    setTwofaCode('');

    try {
      const result = await api.setupUser2FA(item.id);
      setTwofaModal({
        user: item,
        qr: result.qr,
        secret: result.secret
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading2FA(false);
    }
  }

  async function enable2FA() {
    if (!twofaModal?.user?.id) return;
    if (!twofaCode.trim()) {
      setError('יש להזין קוד 2FA');
      return;
    }

    setLoading2FA(true);
    setError('');

    try {
      await api.enableUser2FA(twofaModal.user.id, twofaCode.trim());
      setTwofaModal(null);
      setTwofaCode('');
      await loadUsers();
      window.alert('2FA הופעל בהצלחה');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading2FA(false);
    }
  }

  async function disable2FA(item) {
    if (!window.confirm(`לבטל 2FA עבור ${item.username}?`)) return;

    setLoading2FA(true);
    setError('');

    try {
      await api.disableUser2FA(item.id);
      await loadUsers();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading2FA(false);
    }
  }

  if (user.role !== 'admin') {
    return (
      <section className="card glass-card settings-panel">
        <div className="empty">אין הרשאה לניהול משתמשים</div>
      </section>
    );
  }

  return (
    <section className="card glass-card settings-panel">
      <div className="card-title-row">
        <div>
          <div className="section-chip">Users</div>
          <h3>ניהול משתמשים</h3>
        </div>
      </div>

      <div className="settings-grid">
        <label className="field">
          <span>שם משתמש</span>
          <input value={username} onChange={(e) => setUsername(e.target.value)} />
        </label>

        <label className="field">
          <span>סיסמה</span>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </label>

        <label className="field">
          <span>רמה</span>
          <select value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="manager">אחראי</option>
            <option value="admin">מנהל</option>
          </select>
        </label>
      </div>

      <div className="form-actions">
        <button type="button" className="primary-btn" onClick={createUser}>
          צור משתמש
        </button>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>שם משתמש</th>
              <th>רמה</th>
              <th>2FA</th>
              <th>נוצר</th>
              <th>פעולות</th>
            </tr>
          </thead>

          <tbody>
            {users.map((item) => (
              <tr key={item.id}>
                <td>{item.username}</td>

                <td>
                  <select
                    value={item.role}
                    onChange={(e) => changeRole(item, e.target.value)}
                  >
                    <option value="manager">אחראי</option>
                    <option value="admin">מנהל</option>
                  </select>
                </td>

                <td>
                  {item.twofa_enabled ? (
                    <span className="ok-pill">פעיל</span>
                  ) : (
                    <span className="warn-pill">לא פעיל</span>
                  )}
                </td>

                <td>{String(item.created_at || '').slice(0, 10)}</td>

                <td>
                  <div className="row-actions">
                    <button type="button" onClick={() => changePassword(item)}>
                      שנה סיסמה
                    </button>

                    {item.twofa_enabled ? (
                      <button
                        type="button"
                        className="danger"
                        onClick={() => disable2FA(item)}
                        disabled={loading2FA}
                      >
                        בטל 2FA
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setup2FA(item)}
                        disabled={loading2FA}
                      >
                        הפעל 2FA
                      </button>
                    )}

                    <button
                      type="button"
                      className="danger"
                      onClick={() => removeUser(item)}
                    >
                      מחק
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {twofaModal && (
        <div className="field-modal-backdrop" onClick={() => setTwofaModal(null)}>
          <div className="field-modal card glass-card" onClick={(e) => e.stopPropagation()}>
            <div className="field-modal-header">
              <div>
                <div className="section-chip">2FA</div>
                <h3>הפעלת אימות דו־שלבי</h3>
              </div>

              <button
                type="button"
                className="field-modal-close"
                onClick={() => setTwofaModal(null)}
              >
                ✕
              </button>
            </div>

            <div className="field-modal-body">
              <div className="field field-full">
                <span>משתמש</span>
                <strong>{twofaModal.user.username}</strong>
              </div>

              <div className="field field-full">
                <span>סרוק את הקוד באפליקציית Google Authenticator / Microsoft Authenticator</span>
                <div style={{ textAlign: 'center', padding: 12 }}>
                  <img
                    src={twofaModal.qr}
                    alt="2FA QR"
                    style={{
                      width: 220,
                      height: 220,
                      maxWidth: '100%',
                      background: '#fff',
                      borderRadius: 16,
                      padding: 10
                    }}
                  />
                </div>
              </div>

              <label className="field field-full">
                <span>קוד אימות מהאפליקציה</span>
                <input
                  value={twofaCode}
                  onChange={(e) => setTwofaCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  placeholder="123456"
                  inputMode="numeric"
                  maxLength={6}
                />
              </label>

              <div className="field field-full">
                <span>קוד ידני לגיבוי</span>
                <input readOnly value={twofaModal.secret || ''} />
              </div>
            </div>

            <div className="field-modal-actions">
              <button
                type="button"
                className="secondary-btn"
                onClick={() => setTwofaModal(null)}
              >
                ביטול
              </button>

              <button
                type="button"
                className="primary-btn"
                onClick={enable2FA}
                disabled={loading2FA}
              >
                {loading2FA ? 'מאמת...' : 'אמת והפעל 2FA'}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

function TablesTab({ user }) {
  const [customers, setCustomers] = useState([]);
  const [installers, setInstallers] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [customerName, setCustomerName] = useState('');
  const [installerName, setInstallerName] = useState('');
  const [mergeSource, setMergeSource] = useState('');
  const [mergeTarget, setMergeTarget] = useState('');
  const [mergePreview, setMergePreview] = useState(null);
  const [mergeBusy, setMergeBusy] = useState(false);
  const [mergeOpen, setMergeOpen] = useState(false);
  const [statusName, setStatusName] = useState('');
  const [statusColor, setStatusColor] = useState('#64748b');
  const [error, setError] = useState('');
  const [draggedTile, setDraggedTile] = useState(null);
  const [tileOrder, setTileOrder] = useState(() => {
    try {
      return normalizeSettingsTilesOrder(JSON.parse(localStorage.getItem(SETTINGS_TILES_ORDER_KEY) || '[]'));
    } catch {
      return DEFAULT_SETTINGS_TILES_ORDER;
    }
  });

  useEffect(() => {
    localStorage.setItem(SETTINGS_TILES_ORDER_KEY, JSON.stringify(tileOrder));
  }, [tileOrder]);

  function handleTileDragStart(event, tileKey) {
    setDraggedTile(tileKey);
    if (tileKey && event?.dataTransfer) {
      event.dataTransfer.effectAllowed = 'move';
      event.dataTransfer.setData('text/plain', tileKey);
    }
  }

  function handleTileDragOver(event) {
    event.preventDefault();
    if (event?.dataTransfer) event.dataTransfer.dropEffect = 'move';
  }

  function handleTileDrop(event, targetKey) {
    event.preventDefault();
    const sourceKey = draggedTile || event.dataTransfer.getData('text/plain');
    setDraggedTile(null);

    if (!sourceKey || sourceKey === targetKey) return;

    setTileOrder((prev) => {
      const next = normalizeSettingsTilesOrder(prev).filter((key) => key !== sourceKey);
      const targetIndex = next.indexOf(targetKey);
      next.splice(targetIndex < 0 ? next.length : targetIndex, 0, sourceKey);
      return normalizeSettingsTilesOrder(next);
    });
  }

  function resetTileOrder() {
    setTileOrder(DEFAULT_SETTINGS_TILES_ORDER);
  }

  async function loadData() {
    try {
      const [customersData, installersData, statusesData] = await Promise.all([
        api.getCustomers(''),
        api.getInstallers(''),
        api.getStatuses()
      ]);
      setCustomers(customersData);
      setInstallers(installersData);
      setStatuses(statusesData);
      setError('');
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    loadData();
  }, []);

  async function addCustomer() {
    try {
      await api.createCustomer(customerName);
      setCustomerName('');
      loadData();
    } catch (err) {
      setError(err.message);
    }
  }

  async function addInstaller() {
    try {
      await api.createInstaller(installerName);
      setInstallerName('');
      loadData();
    } catch (err) {
      setError(err.message);
    }
  }

  async function previewMerge() {
    setError('');
    setMergePreview(null);
    if (!mergeSource || !mergeTarget || mergeSource === mergeTarget) {
      setError('יש לבחור שני מתקינים שונים');
      return;
    }
    try {
      setMergePreview(await api.previewInstallerMerge(Number(mergeSource), Number(mergeTarget)));
    } catch (err) { setError(err.message); }
  }

  async function confirmMerge() {
    if (!mergePreview || mergeBusy) return;
    setMergeBusy(true);
    try {
      await api.mergeInstallers(mergePreview.source.id, mergePreview.target.id);
      setMergePreview(null);
      setMergeSource('');
      setMergeTarget('');
      setMergeOpen(false);
      await loadData();
    } catch (err) { setError(err.message); }
    finally { setMergeBusy(false); }
  }

  async function addStatus() {
    if (!statusName.trim()) return;
    try {
      await api.createStatus({ label: statusName.trim(), color: statusColor });
      setStatusName('');
      setStatusColor('#64748b');
      loadData();
    } catch (err) {
      setError(err.message);
    }
  }

  async function renameCustomer(item) {
    const name = window.prompt('שם חדש ללקוח', item.name);
    if (name?.trim()) {
      try {
        await api.updateCustomer(item.id, name.trim());
        loadData();
      } catch (err) {
        setError(err.message);
      }
    }
  }

  async function removeCustomer(item) {
    if (window.confirm(`למחוק את ${item.name}?`)) {
      try {
        await api.deleteCustomer(item.id);
        loadData();
      } catch (err) {
        setError(err.message);
      }
    }
  }

  async function renameInstaller(item) {
    const name = window.prompt('שם חדש למתקין', item.name);
    if (name?.trim()) {
      try {
        await api.updateInstaller(item.id, name.trim());
        loadData();
      } catch (err) {
        setError(err.message);
      }
    }
  }

  async function removeInstaller(item) {
    if (window.confirm(`למחוק את ${item.name}?`)) {
      try {
        await api.deleteInstaller(item.id);
        loadData();
      } catch (err) {
        setError(err.message);
      }
    }
  }

  async function editStatus(item) {
    const label = window.prompt('שם סטטוס חדש', item.label);
    if (!label?.trim()) return;

    try {
      await api.updateStatus(item.id, {
        label: label.trim(),
        color: item.color || '#64748b',
        sort_order: item.sort_order || 0
      });
      loadData();
    } catch (err) {
      setError(err.message);
    }
  }

  async function changeStatusColor(item, color) {
    try {
      await api.updateStatus(item.id, {
        label: item.label,
        color,
        sort_order: item.sort_order || 0
      });
      loadData();
    } catch (err) {
      setError(err.message);
    }
  }

  async function removeStatus(item) {
    if (item.is_system) {
      window.alert('לא ניתן למחוק סטטוס מערכת');
      return;
    }

    if (!window.confirm(`למחוק את הסטטוס ${item.label}?`)) return;

    try {
      await api.deleteStatus(item.id);
      loadData();
    } catch (err) {
      setError(err.message);
    }
  }

  const tiles = {
    statuses: (
      <DraggableSettingsTile
        key="statuses"
        tileKey="statuses"
        onDragStart={handleTileDragStart}
        onDragOver={handleTileDragOver}
        onDrop={handleTileDrop}
        isDragging={draggedTile === 'statuses'}
      >
        <div className="card-title-row">
          <div>
            <div className="section-chip">Tables</div>
            <h3>טבלת סטטוסים</h3>
          </div>
        </div>

        <div className="form-actions">
          <input
            value={statusName}
            onChange={(e) => setStatusName(e.target.value)}
            placeholder="סטטוס חדש"
          />
          <input
            type="color"
            className="color-picker-input"
            value={statusColor}
            onChange={(e) => setStatusColor(e.target.value)}
            title="צבע סטטוס"
          />
          <button type="button" className="primary-btn" onClick={addStatus}>
            הוסף סטטוס
          </button>
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>צבע</th>
                <th>שם</th>
                <th>פעולות</th>
              </tr>
            </thead>
            <tbody>
              {statuses.map((item) => (
                <tr key={item.id}>
                  <td>
                    <input
                      type="color"
                      className="color-picker-input"
                      value={item.color || '#64748b'}
                      onChange={(e) => changeStatusColor(item, e.target.value)}
                    />
                  </td>
                  <td>
                    <span className="status-management-pill" style={{ borderColor: item.color || '#64748b' }}>
                      {item.label}
                    </span>
                  </td>
                  <td>
                    <div className="row-actions">
                      <button type="button" onClick={() => editStatus(item)}>ערוך</button>
                      <button
                        type="button"
                        className="danger"
                        disabled={item.is_system}
                        onClick={() => removeStatus(item)}
                      >
                        מחק
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DraggableSettingsTile>
    ),
    customers: (
      <DraggableSettingsTile
        key="customers"
        tileKey="customers"
        onDragStart={handleTileDragStart}
        onDragOver={handleTileDragOver}
        onDrop={handleTileDrop}
        isDragging={draggedTile === 'customers'}
      >
        <div className="card-title-row">
          <div>
            <div className="section-chip">Tables</div>
            <h3>טבלת לקוחות</h3>
          </div>
        </div>

        <div className="form-actions">
          <input
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            placeholder="לקוח חדש"
          />
          <button type="button" className="primary-btn" onClick={addCustomer}>
            הוסף
          </button>
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>שם</th>
                <th>פעולות</th>
              </tr>
            </thead>
            <tbody>
              {customers.map((item) => (
                <tr key={item.id}>
                  <td>{item.name}</td>
                  <td>
                    <div className="row-actions">
                      <button type="button" onClick={() => renameCustomer(item)}>ערוך</button>
                      <button type="button" className="danger" onClick={() => removeCustomer(item)}>מחק</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DraggableSettingsTile>
    ),
    installers: (
      <DraggableSettingsTile
        key="installers"
        tileKey="installers"
        onDragStart={handleTileDragStart}
        onDragOver={handleTileDragOver}
        onDrop={handleTileDrop}
        isDragging={draggedTile === 'installers'}
      >
        <div className="card-title-row">
          <div>
            <div className="section-chip">Tables</div>
            <h3>טבלת מתקינים</h3>
          </div>
        </div>

        <div className="form-actions">
          <input
            value={installerName}
            onChange={(e) => setInstallerName(e.target.value)}
            placeholder="מתקין חדש"
          />
          <button type="button" className="primary-btn" onClick={addInstaller}>
            הוסף
          </button>
        </div>

        {user.role === 'admin' && (
          <div className="installer-merge-trigger">
            <button type="button" className="secondary-btn" onClick={() => setMergeOpen(true)}>מיזוג מתקינים כפולים</button>
          </div>
        )}

        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>שם</th>
                <th>פעולות</th>
              </tr>
            </thead>
            <tbody>
              {installers.map((item) => (
                <tr key={item.id}>
                  <td>{item.name}</td>
                  <td>
                    <div className="row-actions">
                      <button type="button" onClick={() => renameInstaller(item)}>ערוך</button>
                      <button type="button" className="danger" onClick={() => removeInstaller(item)}>מחק</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DraggableSettingsTile>
    )
  };

  return (
    <section className="settings-tables-section">
      <div className="settings-tables-toolbar">
        <span>אפשר לגרור אריחים ולסדר את המסך כמו שנוח לך.</span>
        <button type="button" className="secondary-btn" onClick={resetTileOrder}>איפוס סדר אריחים</button>
      </div>

      <section className="settings-tables-grid">
        {normalizeSettingsTilesOrder(tileOrder).map((key) => tiles[key])}
      </section>


      {user.role === 'admin' && mergeOpen && (
        <div className="installer-merge-overlay" onMouseDown={(e) => { if (e.target === e.currentTarget && !mergeBusy) setMergeOpen(false); }}>
          <section className="installer-merge-dialog" role="dialog" aria-modal="true" aria-labelledby="installer-merge-title" dir="rtl">
            <div className="installer-merge-dialog-header">
              <h3 id="installer-merge-title">מיזוג מתקינים כפולים</h3>
              <button type="button" className="secondary-btn" disabled={mergeBusy} onClick={() => setMergeOpen(false)} aria-label="סגור">✕</button>
            </div>
            <p>בחר מתקין שגוי ומתקין תקין. השיוכים יועברו לתקין ורק לאחר מכן הרישום השגוי יוסר.</p>
            <div className="installer-merge-grid">
              <label className="field"><span>מתקין שגוי (X)</span>
                <select value={mergeSource} onChange={e => { setMergeSource(e.target.value); setMergePreview(null); }}>
                  <option value="">בחר מתקין</option>
                  {installers.map(item => <option key={item.id} value={item.id}>{item.name} (#{item.id})</option>)}
                </select>
              </label>
              <label className="field"><span>מתקין תקין (Y)</span>
                <select value={mergeTarget} onChange={e => { setMergeTarget(e.target.value); setMergePreview(null); }}>
                  <option value="">בחר מתקין</option>
                  {installers.map(item => <option key={item.id} value={item.id}>{item.name} (#{item.id})</option>)}
                </select>
              </label>
            </div>
            <button type="button" className="secondary-btn" disabled={mergeBusy || !mergeSource || !mergeTarget || mergeSource === mergeTarget} onClick={previewMerge}>בדוק שיוכים לפני מיזוג</button>
            {mergePreview && (
              <div className="installer-merge-preview" role="status">
                <strong>בדיקה לפני ביצוע</strong>
                <p>העברה מ־{mergePreview.source.name} אל {mergePreview.target.name}</p>
                <p>{mergePreview.rows_count} רשומות ב־{mergePreview.projects_count} פרויקטים יועברו.</p>
                <p>הפעולה אינה ניתנת לביטול אוטומטי. ודא שנבחרו המתקינים הנכונים.</p>
                <div className="row-actions">
                  <button type="button" className="danger" disabled={mergeBusy} onClick={confirmMerge}>{mergeBusy ? 'מבצע מיזוג…' : 'אשר מיזוג והסר רישום שגוי'}</button>
                  <button type="button" className="secondary-btn" disabled={mergeBusy} onClick={() => setMergePreview(null)}>ביטול</button>
                </div>
              </div>
            )}
          </section>
        </div>
      )}

      {error && <div className="error-box">{error}</div>}
    </section>
  );
}
export default function SettingsPage({
  user,
  onBack,
  onLogout,
  displaySettings,
  setDisplaySettings
}) {
  const tabs = useMemo(() => [
    { key: 'display', label: 'תצוגה' },
    { key: 'tables', label: 'טבלאות' },
    ...(user.role === 'admin' ? [{ key: 'users', label: 'משתמשים' }] : [])
  ], [user.role]);

  const [activeTab, setActiveTab] = useState(tabs[0].key);

  useEffect(() => {
    if (!tabs.some((tab) => tab.key === activeTab)) {
      setActiveTab(tabs[0].key);
    }
  }, [tabs, activeTab]);

  return (
    <div className="app-shell app-shell-projects">
      <main className="main-panel single-panel">
        <section className="hero-with-brand">
          <section className="toolbar card glass-card hero-toolbar">
            <div>
              <div className="section-chip">Settings</div>
              <h2>הגדרות מערכת</h2>
              <p>ניהול משתמשים, 2FA, תצוגה, זום וטבלאות בסיס.</p>
            </div>

            <div className="toolbar-actions">
              <button type="button" className="secondary-btn" onClick={onBack}>חזרה</button>
              <button type="button" className="secondary-btn" onClick={onLogout}>התנתק</button>
              <span className="rows-badge">{user.username} / {user.role}</span>
            </div>
          </section>

          <AppBrand />
        </section>

        <section className="settings-tabs">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              type="button"
              className={`settings-tab ${activeTab === tab.key ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.key)}
            >
              {tab.label}
            </button>
          ))}
        </section>

        {activeTab === 'display' && (
          <DisplaySettingsTab
            displaySettings={displaySettings}
            setDisplaySettings={setDisplaySettings}
          />
        )}

        {activeTab === 'tables' && <TablesTab user={user} />}
        {activeTab === 'users' && <UsersTab user={user} />}
      </main>
    </div>
  );
}